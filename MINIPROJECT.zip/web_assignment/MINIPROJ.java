import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class MINIPROJ{
public static void main(String[] args) throws ClassNotFoundException, SQLException{
Class.forName("com.mysql.cj.jdbc.Driver");
Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3308/try1?","root","2904");
Statement statement = connection.createStatement();
ResultSet rs = statement.executeQuery("select *from trending");
System.out.println("...entered details...");
System.out.println("MOVIE_NAME\t\tYEAR\tDIRECTOR_NAME");
while(rs.next()){
String na1=rs.getString("m_name");
int a1=rs.getInt("year1");
String bg1=rs.getString("d_name");
System.out.println(na1+"\t\t"+a1+"\t"+bg1);}
statement.close();
connection.close();}}
