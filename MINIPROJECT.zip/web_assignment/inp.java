import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class input extends HttpServlet{
protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException{
String text1=(String) request.getParameter("username") ;//explicit type conversion
String text2=(String) request.getParameter("password") ;
HttpSession session1 = request.getSession();
session1.setAttribute("username",text1);
session1.setAttribute("password",text2);
response.sendRedirect("inp");}}
