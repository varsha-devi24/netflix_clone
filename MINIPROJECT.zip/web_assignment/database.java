import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class database {
public static Connection con() throws ClassNotFoundException, SQLException{
Class.forName("com.mysql.cj.jdbc.Driver");
Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3308/hjdbc?","root","2904");
return connection;}
}
