#create database try1;
use try1;
create table trending(
m_name varchar(20),
year1 int,
d_name varchar(20));
insert into trending (m_name,year1,d_name)
values ("avatar ",2009,"james"),
("enchanted ",2007,"kevin"),
("up",2009,"pete"),
("frozen",2013,"chris"),
("frozen 2",2019,"chris")
("cinderlla",2015,"kenneth");
