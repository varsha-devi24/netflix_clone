import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class display extends HttpServlet{
protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException{
PrintWriter out=response.getWriter();
HttpSession session=request.getSession();
String user=(String)request.getParameter("username");
String pass=(String)request.getParameter("password");
out.println("welcome to servlet.CLIENT SIDE..");
out.println("entered user="+user);//clinet side
System.out.println("WELCOME TO SERVELT ..SERVER SIDE..");
System.out.println("ENTERED password.."+pass);}}
